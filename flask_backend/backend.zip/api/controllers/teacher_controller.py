"""
Teacher Review Dashboard controller.
Implements US13 (view review submissions), US14 (add conclusion note),
and US7/US8 extension (assignment analytics & CSV export).

Endpoints:
    GET  /teacher/assignments/<assignment_id>/reviews
    GET  /teacher/assignments/<assignment_id>/reviews/<review_id>
    POST /teacher/reviews/<review_id>/conclusion
    GET  /teacher/assignments/<assignment_id>/analytics
    GET  /teacher/assignments/<assignment_id>/export
"""

import csv
import io
import statistics

from flask import Blueprint, Response, jsonify, request
from flask_jwt_extended import get_jwt_identity

from ..models import (
    Assignment,
    CriteriaDescription,
    Criterion,
    CourseGroup,
    Group_Members,
    Review,
    Rubric,
    User,
)
from ..models.conclusion_model import Conclusion
from ..models.db import db
from .auth_controller import jwt_teacher_required

teacher_bp = Blueprint("teacher", __name__, url_prefix="/teacher")


# ── Private helper ────────────────────────────────────────────────────────────

def _review_total_score(review) -> int:
    """
    Sum the grades across all Criterion rows for this review.

    This project stores per-criterion scores in the Criterion table
    (columns: grade, comments) linked back to CriteriaDescription
    for the question text and scoreMax.
    criteria is a dynamic relationship so we call .all() to load it.
    """
    return sum(
        (c.grade or 0)
        for c in review.criteria.all()
    )


# ============================================================
# GET /teacher/assignments/<assignment_id>/reviews
# List all reviews for an assignment (teacher/admin only)
# ============================================================

@teacher_bp.route("/assignments/<int:assignment_id>/reviews", methods=["GET"])
@jwt_teacher_required
def list_assignment_reviews(assignment_id):
    """
    Return a summary list of all peer reviews submitted for an assignment.

    Query parameters:
        group_id (int, optional) — filter to reviewees who belong to this group
        sort     (str, optional) — 'id' (default) or 'score' (descending)

    Response 200:
        [
            {
                "review_id":      int,
                "reviewer_id":    int,
                "reviewee_id":    int,
                "total_score":    int,
                "has_conclusion": bool
            },
            ...
        ]

    Response 404: assignment not found
    """
    assignment = Assignment.get_by_id(assignment_id)
    if assignment is None:
        return jsonify({"msg": "Assignment not found"}), 404

    group_id = request.args.get("group_id", None, type=int)
    sort_by  = request.args.get("sort", "id")

    # ── Base query ────────────────────────────────────────────────────────────
    query = Review.query.filter_by(assignmentID=assignment_id)

    # ── Optional group filter ─────────────────────────────────────────────────
    if group_id is not None:
        # Resolve the group, return 404 if it doesn't exist
        group = CourseGroup.get_by_id(group_id)
        if group is None:
            return jsonify({"msg": "Group not found"}), 404

        member_ids = [
            m.userID
            for m in Group_Members.query.filter_by(groupID=group_id).all()
        ]
        query = query.filter(Review.revieweeID.in_(member_ids))

    reviews = query.all()

    # ── Optional sort ─────────────────────────────────────────────────────────
    if sort_by == "score":
        reviews = sorted(reviews, key=_review_total_score, reverse=True)

    return jsonify([
        {
            "review_id":      r.id,
            "reviewer_id":    r.reviewerID,
            "reviewee_id":    r.revieweeID,
            "total_score":    _review_total_score(r),
            "has_conclusion": r.conclusion is not None,
        }
        for r in reviews
    ]), 200


# ============================================================
# GET /teacher/assignments/<assignment_id>/reviews/<review_id>
# Full detail for one review: criteria breakdown + conclusion
# ============================================================

@teacher_bp.route(
    "/assignments/<int:assignment_id>/reviews/<int:review_id>",
    methods=["GET"],
)
@jwt_teacher_required
def get_review_detail(assignment_id, review_id):
    """
    Return the full detail of a single peer review, including each
    criterion's score and comment, and the conclusion note if one exists.

    Response 200:
        {
            "review_id":   int,
            "reviewer_id": int,
            "reviewee_id": int,
            "criteria": [
                {
                    "criterion_id":   int,
                    "criterion_name": str,
                    "score":          int | null,
                    "score_max":      int | null,
                    "comment":        str
                },
                ...
            ],
            "conclusion": { ...to_dict() } | null
        }

    Response 404: assignment or review not found
    """
    assignment = Assignment.get_by_id(assignment_id)
    if assignment is None:
        return jsonify({"msg": "Assignment not found"}), 404

    review = Review.query.filter_by(
        id=review_id, assignmentID=assignment_id
    ).first()
    if review is None:
        return jsonify({"msg": "Review not found"}), 404

    # ── Build criteria breakdown ──────────────────────────────────────────────
    # Each Criterion row has a grade + comments, and a FK to CriteriaDescription
    # which holds the human-readable question and scoreMax.
    criteria_breakdown = [
        {
            "criterion_id":   c.id,
            "criterion_name": (
                c.criterion_row.question if c.criterion_row else ""
            ),
            "score":          c.grade,
            "score_max":      (
                c.criterion_row.scoreMax if c.criterion_row else None
            ),
            "comment":        c.comments or "",
        }
        for c in review.criteria.all()
    ]

    conclusion = Conclusion.get_by_review(review_id)

    return jsonify({
        "review_id":   review.id,
        "reviewer_id": review.reviewerID,
        "reviewee_id": review.revieweeID,
        "criteria":    criteria_breakdown,
        "conclusion":  conclusion.to_dict() if conclusion else None,
    }), 200


# ============================================================
# POST /teacher/reviews/<review_id>/conclusion
# Create or update the conclusion note for a review (upsert)
# ============================================================

@teacher_bp.route("/reviews/<int:review_id>/conclusion", methods=["POST"])
@jwt_teacher_required
def upsert_conclusion(review_id):
    """
    Create or update the instructor note (Conclusion) on a peer review.
    Behaves as an upsert: a second POST to the same review_id updates
    the existing note rather than creating a duplicate.

    Request body (JSON):
        { "note": str }

    Response 200: conclusion.to_dict()
    Response 400: empty note
    Response 404: review not found
    """
    review = Review.get_by_id(review_id)
    if review is None:
        return jsonify({"msg": "Review not found"}), 404

    note = (request.json or {}).get("note", "").strip()
    if not note:
        return jsonify({"error": "Note cannot be empty"}), 400

    # ── Resolve the teacher from the JWT cookie ───────────────────────────────
    email = get_jwt_identity()
    teacher = User.get_by_email(email)
    if teacher is None:
        return jsonify({"msg": "User not found"}), 404

    # ── Upsert ────────────────────────────────────────────────────────────────
    existing = Conclusion.get_by_review(review_id)
    if existing:
        existing.note = note
        existing.update()
    else:
        existing = Conclusion(
            reviewID=review_id,
            teacherID=teacher.id,
            note=note,
        )
        Conclusion.create(existing)

    return jsonify(existing.to_dict()), 200


# ============================================================
# GET /teacher/assignments/<assignment_id>/analytics
# Per-criterion averages, completion rate, outlier detection
# ============================================================

@teacher_bp.route("/assignments/<int:assignment_id>/analytics", methods=["GET"])
@jwt_teacher_required
def assignment_analytics(assignment_id):
    """
    Return analytics for an assignment: completion rate, per-criterion
    average scores, and flagged outlier reviews (>2 std deviations).

    Response 200:
        {
            "assignment_id":   int,
            "assignment_name": str,
            "completion_pct":  float,
            "total_students":  int,
            "submitted":       int,
            "criteria":        [ { criterion_id, criterion_name, score_max,
                                   avg_score, response_count } ],
            "outliers":        [ { review_id, reviewer_id, reviewee_id,
                                   total_score, deviation } ]
        }

    Response 404: assignment not found
    """
    assignment = Assignment.get_by_id(assignment_id)
    if assignment is None:
        return jsonify({"msg": "Assignment not found"}), 404

    # --- Completion rate ---
    total_students = (
        db.session.query(Group_Members.userID)
        .join(CourseGroup, CourseGroup.id == Group_Members.groupID)
        .filter(CourseGroup.assignmentID == assignment_id)
        .distinct()
        .count()
    )
    submitted = (
        Review.query
        .filter_by(assignmentID=assignment_id)
        .with_entities(Review.reviewerID)
        .distinct()
        .count()
    )
    completion_pct = (
        round((submitted / total_students * 100), 1) if total_students else 0
    )

    # --- Per-criterion averages ---
    crit_descs = (
        CriteriaDescription.query
        .join(Rubric, Rubric.id == CriteriaDescription.rubricID)
        .filter(Rubric.assignmentID == assignment_id)
        .all()
    )

    criterion_data = []
    all_review_totals = []
    for cd in crit_descs:
        scores = [
            c.grade
            for c in Criterion.query.filter_by(criterionRowID=cd.id).all()
            if c.grade is not None
        ]
        avg = round(statistics.mean(scores), 2) if scores else 0
        criterion_data.append({
            "criterion_id": cd.id,
            "criterion_name": cd.question,
            "score_max": cd.scoreMax,
            "avg_score": avg,
            "response_count": len(scores),
        })
        all_review_totals.extend(scores)

    # --- Outlier detection (>2 std deviations from mean) ---
    outliers = []
    if len(all_review_totals) >= 2:
        mean = statistics.mean(all_review_totals)
        stdev = statistics.stdev(all_review_totals)
        threshold = 2 * stdev

        reviews = Review.query.filter_by(assignmentID=assignment_id).all()
        for rev in reviews:
            total = sum(
                (c.grade or 0) for c in rev.criteria.all()
            )
            if abs(total - mean) > threshold:
                outliers.append({
                    "review_id": rev.id,
                    "reviewer_id": rev.reviewerID,
                    "reviewee_id": rev.revieweeID,
                    "total_score": total,
                    "deviation": round(total - mean, 2),
                })

    return jsonify({
        "assignment_id": assignment_id,
        "assignment_name": assignment.name,
        "completion_pct": completion_pct,
        "total_students": total_students,
        "submitted": submitted,
        "criteria": criterion_data,
        "outliers": outliers,
    }), 200


# ============================================================
# GET /teacher/assignments/<assignment_id>/export
# CSV export of all raw review data for an assignment
# ============================================================

@teacher_bp.route("/assignments/<int:assignment_id>/export", methods=["GET"])
@jwt_teacher_required
def export_reviews_csv(assignment_id):
    """
    Export all review scores for an assignment as a downloadable CSV file.

    Columns: review_id, reviewer_id, reviewee_id, criterion, score,
             max_score, comment

    Response 200: text/csv attachment
    Response 404: assignment not found
    """
    assignment = Assignment.get_by_id(assignment_id)
    if assignment is None:
        return jsonify({"msg": "Assignment not found"}), 404

    reviews = Review.query.filter_by(assignmentID=assignment_id).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "review_id", "reviewer_id", "reviewee_id",
        "criterion", "score", "max_score", "comment",
    ])

    for rev in reviews:
        for c in rev.criteria.all():
            writer.writerow([
                rev.id,
                rev.reviewerID,
                rev.revieweeID,
                c.criterion_row.question if c.criterion_row else "",
                c.grade,
                c.criterion_row.scoreMax if c.criterion_row else "",
                c.comments or "",
            ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={
            "Content-Disposition":
                f"attachment;filename=assignment_{assignment_id}_reviews.csv"
        },
    )
